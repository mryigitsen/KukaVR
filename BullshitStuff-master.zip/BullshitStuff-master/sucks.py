  #!/usr/bin/env python

import rospy
import math
from std_msgs.msg import Float64MultiArray, Int64MultiArray

def callback(data):
    rospy.loginfo(rospy.get_caller_id() + " Published array of positions: " + data.data)

def convert():
    rospy.init_node('converter', anonymous=True)
    
    sub=rospy.Subscriber('/standing2/degreesPoints', Int64MultiArray, callback)
    pub=rospy.Publisher('/standing2/joint_impedance_controller/position', Float64MultiArray, queue_size=10)
    
    rate=rospy.Rate(10)
    
    while not rospy.is_shutdown():
        new_array = []
        for deg in sub:
            rad = math.radians(deg)
            new_array.append(rad)
        pub.publish(new_array)
        rate.sleep()
            
if __name__ == '__main__':
    try:
        convert()
    except rospy.ROSInterruptException:
        pass
